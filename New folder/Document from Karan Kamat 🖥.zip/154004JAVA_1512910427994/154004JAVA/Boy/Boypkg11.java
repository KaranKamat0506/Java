package Boy;
public class Boypkg11{
	public int age;
	public String name;
	public void getData(){
		name="Amit";
		age=18;
	}
	public void putData(){
		System.out.println("\nName :"+name+"Age :"+age);
	}
}

