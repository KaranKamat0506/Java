public class wrap4{
	public static void main(String args[]){
		int a=5;  
		Integer b=new Integer(a);    
		int c=a + b.intValue();    
		System.out.println("\na : "+a+"\nb : "+b+"\nAddition : "+c);    
	}
}
