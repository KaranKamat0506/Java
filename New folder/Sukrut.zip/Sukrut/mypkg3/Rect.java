package mypkg3;

public class Rect{
	public static void Area() {
		int length=20;
		int breadth=40;
		System.out.println("Area:" + (length*breadth));
	}
}