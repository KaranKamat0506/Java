import mypkg3.Rect;

class Test4{
	public static void main(String[] args) {
		Rect.Area();
	}
}