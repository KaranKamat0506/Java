import java.applet.*;
import java.awt.*;

public class Circle extends Applet{
    public void paint(Graphics g){
        g.drawOval(500,100,300,300);
    }
}