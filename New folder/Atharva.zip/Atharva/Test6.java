import mypkg6.Even;

class Test6{
	public static void main(String[] args) {
		Even.EvenNum();
	}
}