package mypkg6;

public class Even{
	public static void EvenNum() {
		for(int i=1;i<=10;i++){
			if (i%2==0) {
				System.out.println("\t" + i);
			}
		}

	}
}